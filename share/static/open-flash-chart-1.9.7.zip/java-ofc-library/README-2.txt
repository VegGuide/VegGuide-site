I know nothing about Java, so here is the email that came with this code:

----------------------

Hey!
Thanks for a cool charting package.
I took a long detour when I saw that the external Java library project
has Struts dependencies, etc. etc.  So instead of porting to
ActionScript 3.0 which I thought might be useful, I took on creating a
much simpler Java wrapper.

I've attached three files that recreate your first tutorial.  You can
add them to your codebase or whatever.  I'm hooked up with Subversion,
so if you want me to commit, that's fine also.
Graph.java - this should go in org.openflashchart or whatever package
you prefer.  The JSP files can go whereever.

Thanks again,
Mark