Hello,

  Disclaimer: I don't know anything about Ruby.
  
  Arnold Cano sent me this code:
  
  Email: arnoldc@mcmservice.com
  Web: http://www.mcmservice.com
  
  Take a look at the source to see what it can do. Also check
  out the other Ruby library included, it may suit your needs
  better than this one. Choice is a good thing :-)
  
  Either way, I'm sure just a quick glance at the source will
  prove how useful this little library is :-)
  
  Good luck,
  
  monk.e.boy