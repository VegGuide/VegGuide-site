# Include hook code here
require 'open_flash_chart'

